from django.apps import AppConfig


class FoodplazaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Foodplazaapp'
