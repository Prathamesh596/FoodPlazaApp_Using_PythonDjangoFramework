from django.contrib import admin
from Foodplazaapp.models import Food,Customer,Admin,Cart,Orders

# Register your models here.
admin.site.register(Food),
admin.site.register(Customer),
admin.site.register(Admin),
admin.site.register(Cart),
admin.site.register(Orders),


